﻿namespace Sarvicny.Contracts.Payment.Response
{
    public class ApiResponse
    {
        public string Token { get; set; }
    }
}
